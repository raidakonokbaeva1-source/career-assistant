"""
Карьерный помощник — ИИ-агент для резюме и собеседований.

Как это устроено (коротко):
  • Интерфейс (страница сайта) — библиотека Streamlit.
  • «Мозг» — языковая модель через Groq API.
  • «Руки» (инструменты) — функции на Python ниже: читать базу знаний,
    читать загруженное резюме, создавать файлы Word.
  • Модель сама решает, какой инструмент вызвать (function calling).

Обычно здесь ничего менять не нужно. Свой помощник настраивается в файлах:
  system_prompt.md  — кто он и как себя ведёт;
  knowledge/        — документы, на которые он опирается.
"""

import io
import json
import os
import re
from datetime import datetime
from pathlib import Path

import streamlit as st
from docx import Document
from docx.shared import Pt
from openai import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    OpenAI,
    RateLimitError,
)
from pypdf import PdfReader

# =====================================================================
# 1. НАСТРОЙКИ (можно менять)
# =====================================================================

APP_ICON = "💼"

# Модели по порядку: если первая упёрлась в лимит, берётся следующая.
DEFAULT_MODELS = [
    "openai/gpt-oss-120b",
    "llama-3.3-70b-versatile",
    "openai/gpt-oss-20b",
]
DEFAULT_BASE_URL = "https://api.groq.com/openai/v1"

MAX_HISTORY = 10           # сколько последних сообщений чата видит помощник
MAX_FILE_CHARS = 8000      # сколько символов резюме читать (остальное обрезается)
MAX_KNOWLEDGE_CHARS = 6000 # сколько символов одного документа базы знаний читать
MAX_TOOL_STEPS = 5         # сколько раз подряд помощник может вызвать инструменты
MAX_ANSWER_TOKENS = 3000   # максимальная длина одного ответа модели
TEMPERATURE = 0.5          # 0 — строго и одинаково, 1 — творчески
REASONING_EFFORT = "low"   # для моделей gpt-oss: low / medium / high

BASE_DIR = Path(__file__).parent
SYSTEM_PROMPT_FILE = BASE_DIR / "system_prompt.md"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"
KNOWLEDGE_TYPES = (".md", ".txt", ".docx", ".pdf")

# =====================================================================
# 2. ТЕКСТЫ ИНТЕРФЕЙСА НА ДВУХ ЯЗЫКАХ
# =====================================================================

TEXTS = {
    "ru": {
        "title": "Карьерный помощник",
        "caption": "Помогу улучшить резюме и подготовиться к собеседованию",
        "welcome": (
            "Здравствуйте! 👋 Я помогу проверить и улучшить резюме, "
            "сделать его в Word и потренироваться перед собеседованием.\n\n"
            "Загрузите резюме или выберите действие ниже."
        ),
        "upload": "📎 Загрузите резюме (PDF или Word)",
        "uploaded": "Резюме загружено: {name}",
        "unreadable": (
            "Не получилось прочитать текст из файла. Возможно, это скан или фото. "
            "Загрузите Word (.docx) или PDF с текстом."
        ),
        "quick": [
            "📝 Проверь моё резюме",
            "🎤 Проведи пробное собеседование",
            "📄 Помоги составить резюме с нуля",
        ],
        "placeholder": "Напишите сообщение…",
        "thinking": "Думаю…",
        "clear": "🗑 Очистить чат",
        "download": "⬇️ Скачать {name}",
        "limit": (
            "⏳ Бесплатный лимит запросов сейчас закончился. Подождите 1–2 минуты "
            "и попробуйте снова. Если так весь день — закончился дневной лимит, "
            "попробуйте завтра."
        ),
        "too_long": (
            "📏 Запрос получился слишком большим для бесплатного лимита. "
            "Нажмите «Очистить чат» и попробуйте снова."
        ),
        "bad_key": "🔑 Ключ API не подходит. Проверьте GROQ_API_KEY в Settings → Secrets.",
        "error": "😕 Что-то пошло не так. Попробуйте ещё раз через минуту.",
        "details": "Подробности ошибки (для владельца)",
        "password": "Введите пароль",
        "wrong_password": "Неверный пароль",
        "lang_hint": "Язык интерфейса — русский. Отвечай по-русски, если пользователь не пишет на другом языке.",
        "report_title": "Отчёт о пробном собеседовании",
        "report_position": "Должность",
        "report_overall": "Общая оценка",
        "report_questions": "Вопросы и оценки",
        "report_score": "Оценка",
        "report_strengths": "Сильные стороны",
        "report_improve": "Что улучшить",
        "resume_file": "Резюме",
        "report_file": "Отчёт_собеседование",
    },
    "ky": {
        "title": "Карьералык жардамчы",
        "caption": "Резюмеңизди жакшыртууга жана маекке даярданууга жардам берем",
        "welcome": (
            "Саламатсызбы! 👋 Мен резюмеңизди текшерип, жакшыртып, Word форматында "
            "даярдап берем жана маекке машыгууга жардам берем.\n\n"
            "Резюмеңизди жүктөңүз же төмөндөн аракетти тандаңыз."
        ),
        "upload": "📎 Резюмеңизди жүктөңүз (PDF же Word)",
        "uploaded": "Резюме жүктөлдү: {name}",
        "unreadable": (
            "Файлдагы текст окулбай калды. Балким, бул скан же сүрөт. "
            "Тексти бар Word (.docx) же PDF жүктөңүз."
        ),
        "quick": [
            "📝 Резюмемди текшерип бер",
            "🎤 Маекке машыгалы",
            "📄 Резюмени нөлдөн түзүүгө жардам бер",
        ],
        "placeholder": "Билдирүү жазыңыз…",
        "thinking": "Ойлонуп жатам…",
        "clear": "🗑 Чатты тазалоо",
        "download": "⬇️ Жүктөп алуу: {name}",
        "limit": (
            "⏳ Акысыз лимит азыр бүттү. 1–2 мүнөт күтүп, кайра аракет кылыңыз. "
            "Эгер күн бою ушундай болсо — күндүк лимит бүттү, эртең аракет кылыңыз."
        ),
        "too_long": (
            "📏 Суроо-талап акысыз лимит үчүн өтө чоң болуп калды. "
            "«Чатты тазалоо» баскычын басып, кайра аракет кылыңыз."
        ),
        "bad_key": "🔑 API ачкычы туура эмес. Settings → Secrets ичиндеги GROQ_API_KEY текшериңиз.",
        "error": "😕 Бир нерсе туура эмес болду. Бир мүнөттөн кийин кайра аракет кылыңыз.",
        "details": "Катанын чоо-жайы (ээси үчүн)",
        "password": "Сырсөздү киргизиңиз",
        "wrong_password": "Сырсөз туура эмес",
        "lang_hint": "Интерфейстин тили — кыргызча. Колдонуучу башка тилде жазбаса, кыргызча (кирилл арибинде) жооп бер.",
        "report_title": "Машыгуу маегинин жыйынтыгы",
        "report_position": "Кызмат орду",
        "report_overall": "Жалпы баа",
        "report_questions": "Суроолор жана баалар",
        "report_score": "Баа",
        "report_strengths": "Күчтүү жактары",
        "report_improve": "Эмнени жакшыртуу керек",
        "resume_file": "Резюме",
        "report_file": "Маек_жыйынтыгы",
    },
}
LANGS = {"Русский": "ru", "Кыргызча": "ky"}


def t(key):
    """Текст интерфейса на выбранном языке."""
    return TEXTS[st.session_state.get("lang", "ru")][key]


# =====================================================================
# 3. СЕКРЕТЫ (ключ API и пароль берутся из Settings → Secrets)
# =====================================================================

def get_secret(name, default=None):
    try:
        if name in st.secrets:
            return st.secrets[name]
    except Exception:
        pass  # файла с секретами нет — это нормально
    return os.environ.get(name, default)


API_KEY = get_secret("API_KEY") or get_secret("GROQ_API_KEY")
BASE_URL = get_secret("BASE_URL") or DEFAULT_BASE_URL
MODELS = [m.strip() for m in str(get_secret("MODELS") or "").split(",") if m.strip()] or DEFAULT_MODELS
APP_PASSWORD = get_secret("APP_PASSWORD")
IS_GROQ = "groq.com" in BASE_URL

# =====================================================================
# 4. РАБОТА С ФАЙЛАМИ
# =====================================================================

def extract_text(filename, data):
    """Достаёт текст из PDF, Word (.docx) или текстового файла."""
    name = filename.lower()
    if name.endswith(".pdf"):
        reader = PdfReader(io.BytesIO(data))
        text = "\n".join((page.extract_text() or "") for page in reader.pages)
    elif name.endswith(".docx"):
        doc = Document(io.BytesIO(data))
        parts = [p.text for p in doc.paragraphs]
        for table in doc.tables:  # резюме часто сделаны таблицей
            for row in table.rows:
                cells = []
                for cell in row.cells:
                    if cell.text.strip() and cell.text not in cells:
                        cells.append(cell.text)
                parts.append(" | ".join(cells))
        text = "\n".join(parts)
    elif name.endswith((".md", ".txt")):
        text = data.decode("utf-8", errors="ignore")
    else:
        text = ""
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def cut(text, limit):
    """Обрезает слишком длинный текст, чтобы не тратить лимит."""
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\n[…текст обрезан, слишком длинный…]"


def knowledge_files():
    """Список документов базы знаний (файлы на «_» пропускаются)."""
    if not KNOWLEDGE_DIR.exists():
        return []
    return sorted(
        p for p in KNOWLEDGE_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in KNOWLEDGE_TYPES and not p.name.startswith("_")
    )


def safe_filename(text):
    text = re.sub(r"[^\w\-]+", "_", str(text), flags=re.UNICODE).strip("_")
    return text[:40] or "file"


def new_document():
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)
    return doc


def to_bytes(doc):
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def build_resume_docx(args):
    doc = new_document()
    doc.add_heading(str(args.get("full_name", "")).strip() or "—", level=0)
    if args.get("headline"):
        run = doc.add_paragraph().add_run(str(args["headline"]))
        run.bold = True
        run.font.size = Pt(13)
    if args.get("contacts"):
        doc.add_paragraph(str(args["contacts"]))
    for section in args.get("sections") or []:
        if not isinstance(section, dict):
            continue
        doc.add_heading(str(section.get("title", "")), level=1)
        items = section.get("items") or []
        if isinstance(items, str):
            items = [items]
        items = [str(i).strip() for i in items if str(i).strip()]
        if len(items) == 1:
            doc.add_paragraph(items[0])
        else:
            for item in items:
                doc.add_paragraph(item, style="List Bullet")
    return to_bytes(doc)


def to_int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return value


def build_report_docx(args):
    doc = new_document()
    doc.add_heading(t("report_title"), level=0)
    doc.add_paragraph(f"{t('report_position')}: {args.get('position', '—')}")
    doc.add_paragraph(datetime.now().strftime("%d.%m.%Y"))
    overall = doc.add_paragraph().add_run(f"{t('report_overall')}: {to_int(args.get('overall_score', '—'))} / 10")
    overall.bold = True
    overall.font.size = Pt(14)

    doc.add_heading(t("report_questions"), level=1)
    for number, q in enumerate(args.get("questions") or [], start=1):
        if not isinstance(q, dict):
            continue
        p = doc.add_paragraph()
        p.add_run(f"{number}. {q.get('question', '')}").bold = True
        doc.add_paragraph(f"{t('report_score')}: {to_int(q.get('score', '—'))} / 10")
        if q.get("feedback"):
            doc.add_paragraph(str(q["feedback"]))

    for key, title in (("strengths", "report_strengths"), ("improvements", "report_improve")):
        items = args.get(key) or []
        if isinstance(items, str):
            items = [items]
        if items:
            doc.add_heading(t(title), level=1)
            for item in items:
                doc.add_paragraph(str(item), style="List Bullet")
    return to_bytes(doc)


# =====================================================================
# 5. ИНСТРУМЕНТЫ АГЕНТА (function calling)
# Описания ниже читает модель, чтобы понять, когда что вызывать.
# =====================================================================

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_knowledge",
            "description": "Открыть документ из базы знаний (правила резюме, вопросы и советы для собеседования). Вызывай, когда нужна информация из этих документов.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string", "description": "Имя файла из списка документов базы знаний"}
                },
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_uploaded_resume",
            "description": "Прочитать текст резюме, которое пользователь загрузил на сайт.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_resume_docx",
            "description": "Создать готовое резюме в файле Word (.docx), которое пользователь скачает. Вызывай, когда пользователь просит резюме файлом или в Word.",
            "parameters": {
                "type": "object",
                "properties": {
                    "full_name": {"type": "string", "description": "Имя и фамилия"},
                    "headline": {"type": "string", "description": "Желаемая должность"},
                    "contacts": {"type": "string", "description": "Телефон, email, город, ссылки — одной строкой"},
                    "sections": {
                        "type": "array",
                        "description": "Разделы резюме по порядку",
                        "items": {
                            "type": "object",
                            "properties": {
                                "title": {"type": "string", "description": "Название раздела"},
                                "items": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": "Пункты раздела. Один пункт — обычный абзац, несколько — список.",
                                },
                            },
                            "required": ["title", "items"],
                        },
                    },
                },
                "required": ["full_name", "sections"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "save_interview_report",
            "description": "Создать файл Word с итогами пробного собеседования. Вызывай после последнего вопроса.",
            "parameters": {
                "type": "object",
                "properties": {
                    "position": {"type": "string", "description": "Должность"},
                    "overall_score": {"type": "integer", "description": "Общая оценка от 1 до 10"},
                    "questions": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "question": {"type": "string"},
                                "score": {"type": "integer", "description": "Оценка от 1 до 10"},
                                "feedback": {"type": "string", "description": "Короткий отзыв об ответе"},
                            },
                            "required": ["question", "score", "feedback"],
                        },
                    },
                    "strengths": {"type": "array", "items": {"type": "string"}},
                    "improvements": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["position", "overall_score", "questions"],
            },
        },
    },
]

DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def run_tool(name, raw_args, new_files):
    """Выполняет инструмент, который выбрала модель. Возвращает текст для модели."""
    try:
        args = json.loads(raw_args or "{}") or {}
    except json.JSONDecodeError:
        return "Ошибка: аргументы инструмента должны быть в формате JSON. Попробуй ещё раз."

    try:
        if name == "read_knowledge":
            wanted = str(args.get("filename", "")).strip().lower()
            files = knowledge_files()
            match = next((p for p in files if p.name.lower() == wanted), None) or next(
                (p for p in files if p.stem.lower() == Path(wanted).stem), None
            )
            if not match:
                names = ", ".join(p.name for p in files) or "нет документов"
                return f"Файл «{wanted}» не найден. Доступные документы: {names}"
            return cut(extract_text(match.name, match.read_bytes()), MAX_KNOWLEDGE_CHARS)

        if name == "read_uploaded_resume":
            text = st.session_state.get("resume_text")
            if not text:
                return (
                    "Пользователь ещё не загрузил резюме. Попроси загрузить файл PDF или Word "
                    "через кнопку «📎» вверху страницы или вставить текст резюме в чат."
                )
            return f"Файл: {st.session_state.get('resume_name')}\n\n{text}"

        if name == "create_resume_docx":
            filename = f"{t('resume_file')}_{safe_filename(args.get('full_name', ''))}.docx"
            new_files.append({"name": filename, "data": build_resume_docx(args), "mime": DOCX_MIME})
            return f"Файл «{filename}» создан. Пользователь увидит кнопку «Скачать» под твоим ответом. Коротко скажи, что ты улучшил."

        if name == "save_interview_report":
            filename = f"{t('report_file')}_{datetime.now():%Y-%m-%d}.docx"
            new_files.append({"name": filename, "data": build_report_docx(args), "mime": DOCX_MIME})
            return f"Отчёт «{filename}» создан. Пользователь увидит кнопку «Скачать». Коротко подведи итог и дай 2–3 главных совета."

        return f"Инструмент «{name}» не найден."
    except Exception as error:  # чтобы ошибка в инструменте не ломала весь чат
        return f"Ошибка при выполнении инструмента: {error}"


# =====================================================================
# 6. «МОЗГ» АГЕНТА: запрос к модели и цикл с инструментами
# =====================================================================

@st.cache_resource
def get_client(api_key, base_url):
    return OpenAI(api_key=api_key, base_url=base_url, max_retries=0, timeout=90)


def build_system_prompt():
    prompt = SYSTEM_PROMPT_FILE.read_text(encoding="utf-8") if SYSTEM_PROMPT_FILE.exists() else ""
    docs = "\n".join(f"- {p.name}" for p in knowledge_files()) or "- (документов нет)"
    if st.session_state.get("resume_text"):
        resume = f"Пользователь загрузил резюме «{st.session_state['resume_name']}». Чтобы прочитать — вызови read_uploaded_resume."
    else:
        resume = "Пользователь пока не загружал резюме."
    # Служебная часть добавляется в конец, чтобы начало промпта не менялось.
    return (
        f"{prompt}\n\n---\nСлужебная информация (добавляется автоматически):\n"
        f"Документы в базе знаний (открывай инструментом read_knowledge):\n{docs}\n"
        f"{resume}\n{t('lang_hint')}\nСегодня: {datetime.now():%d.%m.%Y}."
    )


def ask_model(messages):
    """Отправляет запрос. Если модель упёрлась в лимит или недоступна — пробует следующую."""
    client = get_client(API_KEY, BASE_URL)
    last_error = None
    for model in MODELS:
        params = dict(
            model=model,
            messages=messages,
            tools=TOOLS,
            temperature=TEMPERATURE,
            max_completion_tokens=MAX_ANSWER_TOKENS,
        )
        if IS_GROQ and "gpt-oss" in model:
            params["extra_body"] = {"reasoning_effort": REASONING_EFFORT, "include_reasoning": False}
        try:
            response = client.chat.completions.create(**params)
            return response.choices[0].message
        except AuthenticationError:
            raise  # неверный ключ — другие модели не помогут
        except (APIStatusError, APIConnectionError) as error:
            last_error = error  # лимит, модель недоступна и т.п. — пробуем следующую
            continue
    raise last_error


def run_agent():
    """Один ход агента: модель думает, при необходимости вызывает инструменты, отвечает."""
    history = [m for m in st.session_state.messages if not m.get("error")][-MAX_HISTORY:]
    messages = [{"role": "system", "content": build_system_prompt()}]
    messages += [{"role": m["role"], "content": m["content"]} for m in history]
    new_files = []

    for _ in range(MAX_TOOL_STEPS):
        reply = ask_model(messages)
        if not reply.tool_calls:
            return (reply.content or "").strip(), new_files
        messages.append({
            "role": "assistant",
            "content": reply.content or "",
            "tool_calls": [
                {"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}}
                for c in reply.tool_calls
            ],
        })
        for call in reply.tool_calls:
            result = run_tool(call.function.name, call.function.arguments, new_files)
            messages.append({"role": "tool", "tool_call_id": call.id, "content": result})

    # Если инструментов вызвано слишком много — просим просто ответить.
    messages.append({"role": "user", "content": "Ответь пользователю сейчас, без вызова инструментов."})
    reply = ask_model(messages)
    return (reply.content or "").strip(), new_files


def error_text(error):
    status = getattr(error, "status_code", None)
    if isinstance(error, AuthenticationError) or status == 401:
        return t("bad_key")
    if status == 413:
        return t("too_long")
    if isinstance(error, RateLimitError) or status == 429:
        return t("limit")
    return t("error")


# =====================================================================
# 7. ИНТЕРФЕЙС (страница сайта)
# =====================================================================

st.set_page_config(page_title=TEXTS["ru"]["title"], page_icon=APP_ICON, layout="centered")

if "messages" not in st.session_state:
    st.session_state.messages = []
if "lang" not in st.session_state:
    st.session_state.lang = "ru"

# Пароль на вход (только если задан APP_PASSWORD в Secrets)
if APP_PASSWORD and not st.session_state.get("authorized"):
    entered = st.text_input(t("password"), type="password")
    if entered == APP_PASSWORD:
        st.session_state.authorized = True
        st.rerun()
    elif entered:
        st.error(t("wrong_password"))
    st.stop()

if not API_KEY:
    st.error(
        "Не найден ключ GROQ_API_KEY. Откройте настройки приложения: "
        "⋮ → Settings → Secrets и вставьте строку:\n\nGROQ_API_KEY = \"ваш_ключ\""
    )
    st.stop()

header = st.container()  # заголовок покажем над переключателем языка
choice = st.radio("Язык / Тил", list(LANGS), horizontal=True, label_visibility="collapsed")
st.session_state.lang = LANGS[choice]
with header:
    st.header(f"{APP_ICON} {t('title')}")
    st.caption(t("caption"))

# Загрузка резюме
uploaded = st.file_uploader(t("upload"), type=["pdf", "docx"])
if uploaded is not None:
    file_id = f"{uploaded.name}-{uploaded.size}"
    if st.session_state.get("resume_id") != file_id:
        try:
            text = extract_text(uploaded.name, uploaded.getvalue())
        except Exception:
            text = ""
        st.session_state.resume_id = file_id
        st.session_state.resume_name = uploaded.name
        st.session_state.resume_text = cut(text, MAX_FILE_CHARS) if len(text) > 50 else ""
    if st.session_state.resume_text:
        st.success(t("uploaded").format(name=uploaded.name))
    else:
        st.warning(t("unreadable"))


def show_files(files, message_index):
    for j, f in enumerate(files or []):
        st.download_button(
            t("download").format(name=f["name"]),
            data=f["data"],
            file_name=f["name"],
            mime=f["mime"],
            key=f"download_{message_index}_{j}",
        )


def set_pending(text):
    st.session_state.pending = text


# Приветствие и быстрые кнопки (пока чат пустой)
if not st.session_state.messages:
    with st.chat_message("assistant"):
        st.markdown(t("welcome"))
    for i, label in enumerate(t("quick")):
        st.button(label, key=f"quick_{i}", on_click=set_pending, args=(label,), width="stretch")

# История чата
for i, message in enumerate(st.session_state.messages):
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        show_files(message.get("files"), i)

# Новое сообщение
prompt = st.chat_input(t("placeholder"))
if st.session_state.get("pending"):
    prompt = st.session_state.pop("pending")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        failed = None
        with st.spinner(t("thinking")):
            try:
                answer, files = run_agent()
                answer = answer or "…"
            except Exception as error:
                failed, answer, files = error, error_text(error), []
        st.markdown(answer)
        show_files(files, len(st.session_state.messages))
        if failed is not None:
            with st.expander(t("details")):
                st.code(f"{type(failed).__name__}: {failed}")

    st.session_state.messages.append(
        {"role": "assistant", "content": answer, "files": files, "error": failed is not None}
    )

if st.session_state.messages:
    if st.button(t("clear")):
        st.session_state.messages = []
        st.rerun()
